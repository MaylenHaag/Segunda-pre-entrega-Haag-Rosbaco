from setuptools import setup, find_packages

setup(
    name='paquete',
    version='1.0',
    description='Segunda pre-entrega',
    author='Maylen Haag Rosbaco',
    package=find_packages,
    author_email="maylenhaag23@gmail.com"
)